﻿namespace WebQuanLyNhaHang.ViewModel
{
    public class QuantitySelector
    {
       public int? ProductId;
       public int? Soluong;
        public int? DhId;
    }
}
