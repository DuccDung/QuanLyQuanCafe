﻿namespace WebQuanLyNhaHang.ViewModel
{
    public class DonHang_KhachHang
    {
        public int DhId { get; set; }

        public string? GhiChu { get; set; }

        public decimal? TongTien { get; set; }

        //===========================

        public int KhId { get; set; }

        public string? TenKhachHang { get; set; }

        public string? DiaChi { get; set; }

        public string? SoDienThoai { get; set; }
    }
}
