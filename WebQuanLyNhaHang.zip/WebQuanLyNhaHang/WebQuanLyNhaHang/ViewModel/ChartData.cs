﻿namespace WebQuanLyNhaHang.ViewModel
{
    public class ChartData
    {
        public string Name { get; set; }
        public int[] Data { get; set; }
    }
}
